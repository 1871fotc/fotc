Data as represented in the table on https://fotc.org.au/bios/

Data sourced from: 
- [Brisbane City Council's cemeteries search](https://graves.brisbane.qld.gov.au)
- [Obituaries Australia](https://oa.anu.edu.au/obituaries/search/?scope=all&query=Toowong+Cemetery+&x=85&y=18&rs=)
- [Friends of Toowong Cemetery](https://fotc.org.au/)
- and other sources
