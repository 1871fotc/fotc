This data is derived from old and new Brisbane City Council maps of the Toowong Cemetery roads, of public view in the cemetery. 
